package com.nendrasys.services;

import com.nendrasys.model.Data;
import com.nendrasys.model.Employee;
import com.nendrasys.model.Student;
import com.nendrasys.model.StudentList;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RestService {
    private RestTemplate restTemplate;
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    public Employee getRestData(){
        String url="http://dummy.restapiexample.com/api/v1/employees";
        ResponseEntity<Employee> obj = restTemplate.getForEntity(url,Employee.class);
        System.out.println( obj.getStatusCode().value());
        return obj.getBody();
    }
    public StudentList getRestStudentData(){
        Student student = new Student();
        String url ="http://localhost:8085/SpringMVCFormJdbc_war_exploded/studentJson";
        //ResponseEntity<StudentList> obj = restTemplate.getForEntity(url,StudentList.class);
        ResponseEntity<Student[]> obj = restTemplate.getForEntity(url,Student[].class);
        System.out.println(obj.getStatusCode().value());
        StudentList studentList = new StudentList();
        studentList.setStudentList(Arrays.asList(obj.getBody()));
        return studentList;
    }
    /*public Employee createEmployee(){
        List<Employee> employeeList = new ArrayList<>();
        String url = "http://dummy.restapiexample.com/api/v1/employees";
        Employee result= restTemplate.postForObject(url,employeeList,Employee.class);
        return result;
    }*/
}
